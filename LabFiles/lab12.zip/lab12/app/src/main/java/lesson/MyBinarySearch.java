package lesson;

public class MyBinarySearch implements BinarySearchInterface {
    
}

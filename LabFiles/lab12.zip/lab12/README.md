# Lab 12: Searching, Sorting, and Recursion

## Learning Objectives

- Understand Recursion
- Create recursive methods
- Use recursion to iterate over node based structures.
- Understand how recursion is used in searching and sorting algorithms
- Explore some well known common searching and sorting algorithms


## Overview

This project contains the following source files:

- BinarySearchInterface.java - interface for an object that sorts a
  list, searches a list, and reports statistics about the list.  Do
  not modify this file.

- MyBinarySearch.java - class you will implement.  Implements
  BinarySearchInterface.java

- App.java - class you can use to manually test your code.

the following test files:

- BinarySearchTest.java - you need to implement tests for
  BinarySearch.  You should have a minimum of 10 tests.

## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
`./gradlew build`

From a windows terminal, run
`start gradlew.bat build`


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Testing
To test your class, use

`./gradlew test`

To test this project on Windows:
`start gradlew.bat test`



package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/** Tests SayHello class
 * @author: TODO
 */

public class SayHelloTest {

    /**
       Tests SayHello saySomething method
       Asserts saySomething returns the correct string
    */

}

package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/** Tests SayWorld class
 * @author: TODO
 */

public class SayWorldTest {

    /**
       Tests SayWorld saySomething method
       Asserts saySomething returns the correct string
     */
    
}

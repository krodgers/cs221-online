package lesson;

/**
 * DO NOT MODIFY
 * @author spanter, krodgers
 */
public interface Talker {
    /**
     * Method that will return a String that says something :)
     * @return a string containing some text
     */
    public String saySomething();
}

package lesson;

/**
 * Uses Talker objects to say Hello and World
 * @author: TODO
 */

public class App {

    public static void main(String[] args) {
	// Create an array of two Talker objects

	// Create a SayHello object and store it in the array

	// Create a SayWorld object and store it in the array

	// Call the saySomething method of the objects to print their
	// respective messages
	
    }
}

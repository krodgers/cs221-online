package lesson;

/**
 * A friendly class that says "Hello"
 * @author: TODO
 */
public class SayHello implements Talker{

}

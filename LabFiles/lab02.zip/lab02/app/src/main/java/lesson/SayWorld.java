package lesson;

/**
 * A worldly class that says "World"
 * @author: TODO
 */

public class SayWorld implements Talker{

}

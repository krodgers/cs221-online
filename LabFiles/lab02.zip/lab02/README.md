## Lab 2: Intro to Testing

## Learning Objectives

- Use Objects
- Demonstrate inheritance
- Introduce build systems
- Introduce unit testing and Test Driven Development (TDD)
- Introduce the project structure for the labs

## Overview

This project contains the following source files:
SayHello.java - contains a single method that returns the string "Hello"
SayWorld.java - contains a single method that returns the string "World"
Talker.java - Interface defining the saySomething method
App.java - main method

and two test files:
TestSayHello.java - tests the saySomething method of SayHello.java
TestSayWorld.java - tests the saySomething method of SayWorld.java



## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run the main method of the project on Linux, MacOS, or from a VSCode terminal, run
./gradlew run

From a Windows terminal, run
start gradlew.bat run

This will run main() and display the output.

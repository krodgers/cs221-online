# Retrospective

- name: TODO
- email: TODO

## Instructions

For the **Known issues or Bugs** section you need to detail any issues or bugs that you have in your
code. For example maybe your code crashes randomly and you couldn't figure out why. If your code
doesn't have any issues you can simply write NONE in this section.

For the **Sources used** section you must detail any sources you used outside of the textbook or
course website. If you write NONE in this section it is assumed that you didn't use google at all.
Be safe CITE!

## Experience
TODO

- Were there any things that you struggled with? 
- Were there any parts of this lab that were unclear or poorly specified? 
- Were you able to get the entire project done?
- Give a specific example of where polymorphism was used in this lab.
- Suppose there is a list with the methods `putFront`(adds to the
front), `putBack` (adds to the back), `takeFront` (removes from the
front) and `takeBack` (removes from the back).  If you were to
implement a Stack using this list to store the data, which methods
would you use to add and remove from the Stack?
- Suppose there is a list with the methods `putFront`(adds to the
front), `putBack` (adds to the back), `takeFront` (removes from the
front) and `takeBack` (removes from the back).  If you were to
implement a Queue using this list to store the data, which methods
would you use to add and remove from the Queue?


## Known issues or Bugs

TODO

## Sources used

TODO
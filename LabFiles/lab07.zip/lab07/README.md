# Lab 7: CoursePlanner - Course Saga Part 2

## Learning Objectives

- Use generic methods and classes
- Understand generic classes
- Understand how to choose the appropriate linear data structure for a particular application
- Use a Stack (Deque) and Queue


## Overview

This project contains the following source files:

- App.java - Driver class; Allows the user to choose options from a
  menu to search and display courses; partially implemented, you need
  to finish the rest.

- CoursePlanner.java - Contains methods you need to implement. The
  methods process input and returns a data structure of courses in the
  correct order. You should not be opening files or creating Scanners
  in this file - use the parameter objects to process the input.  You
  may assume the data in the input is in the correct format.  This is
  a bad assumption, but adequate for the purposes of this lab.

the following test files:

- CreditCourseTest.java - contains complete tests for
                          CreditCourse.java; do not modify. Do look
                          through the tests to see what is being
                          tested, how the tests are structured, etc.
- CoursePlannerTest.java - contains complete tests for CoursePlanner. Do not modify.


and the following resources files:

- transcript.txt - contains a list of classes listed from the most recently
  		   taken to the earliest taken (i.e. the last
  		   class listed was taken freshman year, the first
  		   class listed was taken senior year)
- yearCourses.txt - contains a list of classes with Fall semester listed first, then Spring semester
- courses.txt - contains a full list of classes reverse ordered by course
  	      	number. Classes with the same last digit are in a
  	      	series and must be taken in series order.  For
  	      	example, EDU 101, EDU 221, EDU 251, EDU 321, EDU 451
  	      	form a series.


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run this project on *nix system:
./gradlew run

To run this project on Windows:
start gradlew.bat run


This will run the main method contained in App.java
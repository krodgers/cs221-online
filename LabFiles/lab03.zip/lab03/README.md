# Lab 3: Inheritance

## Learning Objectives

- Create a derived class from a base class
- Explore how a simple inheritance hierarchy works
- Explore how to program without ever writing a **main** function!

## Overview

This project contains the following source files:

- Book.java - base class, defines a generic book
- Fiction.java - child of Book, defines a Fiction book
- Reference.java - child of Book, defines a Reference book (like a
  dictionary or encyclopedia)
- Catalog.java - represents a collection of books, has the ability to
  print and search the collection

and the following test files:

- BookTest.java - contains tests for the Book class. Use this class as
                an example to write your own tests for the Fiction class.
- FictionTest.java - write tests for the Fiction class
- ReferenceTest.java - write tests for the Reference class
- CatalogTest.java - write tests for the Catalog class


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
This project has no main method.
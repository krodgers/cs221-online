package lesson;
/**
 * Represents a Fiction book
 * @author: TODO
 */

public class Fiction extends Book{
    // Member variables
    // TODO: add other variables
    private String title;

    // TODO:Add constructor and constructor JavaDocs

    @Override
    public String getTitle(){
	return title;
	// this method given as an example
	// Note since Book has JavaDocs, you don't
	// need them in the child class
    }

    // TODO: Override all inherited Book methods

    // TODO: Add toString and toString JavaDocs
    // toString should return a string in the format
    // title - author
    
}

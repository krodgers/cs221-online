package lesson;

/**
   Represents a collection of Books
   @author krodgers, TODO
 */

public class Catalog{
    // Member variables
    private Book[] books;
    private int numBooks; // number of books currently in the catalog

    private final int MAX_BOOKS = 5;

    /**
       Constructor
       Creates an empty catalog of 5 books
       DO NOT MODIFY
     */
    public Catalog(){
	books = new Book[MAX_BOOKS];
	numBooks = 0;
    }


    /**
       Adds a book to the end of the collection
       @return title of book added or null if failed to add
     */
    public String addBook(Book newBook){
	//TODO: Add the book to the array, if possible
	// The book added should go at index numBooks (don't forget to increment numBooks)
	// If there are already MAX_BOOKS books, do nothing and return null
    }

    /**
       Returns a string containing each book's ISBN
       Example: "7864215789211, 7894561233214, 7418529633698, "
     */
    public String listCatalog(){
	// TODO: Create and return a single string that contains each book's ISBN.

	// Iterate through the books array, call getISBN on each
	// object, add the ISBN String to the result string

	// return the result string

    }

}

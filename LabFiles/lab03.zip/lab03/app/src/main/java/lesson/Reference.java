package lesson;
/**
 * Represents a Reference book
 * @author: TODO
 */

public class Reference extends Book{
    // Member variables
    // TODO: Add other variables
    private String title;
    
    // TODO: Add constructor and constructor JavaDocs

    // TODO: Add getSubject and getSubject JavaDocs
    
    @Override
    public String getTitle(){
	return title;
    }

    // TODO: Override all inherited Book methods

    // TODO: Add toString and toString JavaDocs
    // toString should return a String in the format
    // title(subject)
    
}

package lesson;

/**
 * Represents a generic Book. You need to extend this class to create
 * specific versions of a book (ex Fiction, Non-Fiction, etc.)
 * 
 * DO NOT MODIFY
 */
public class Book {

    /**
       Returns the title of the book
    */
    public String getTitle() {
	return "none";
    }

    /**
       Returns the author of the book
    */
    public String getAuthor() {
	return "none";
    }

    /**
       Returns the 13 digit book IBSN 
    */
    public String getISBN() {
	return "none";
    }

    /**
       Returns the genre of the book (e.g. fantasy, sci-fi, self-help,
       etc)
    */
    public String getGenre() {
	return "none";
    }
}

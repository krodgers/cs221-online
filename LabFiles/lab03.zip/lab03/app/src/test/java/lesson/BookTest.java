package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
   Tests the functionality of Book class
   @author spanter, krodgers

   DO NOT MODIFY
 */
public class BookTest {

    @Test
    public void testProperties() {
        Book b = new Book();
        assertEquals(b.getAuthor(), "none");
        assertEquals(b.getGenre(), "none");
        assertEquals(b.getISBN(), "none");
        assertEquals(b.getTitle(), "none");
    }   
}

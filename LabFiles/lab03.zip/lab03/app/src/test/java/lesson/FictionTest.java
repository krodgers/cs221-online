package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
   Tests the Fiction class
   Write methods to ensure every method of Fiction works as intended
   
   @author TODO
*/

public class FictionTest {

    
}

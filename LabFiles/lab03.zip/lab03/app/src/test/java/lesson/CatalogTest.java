package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
   Tests the functionality of Catalog class.

   Note the cases being tested - adding the first book, adding a book
   to a full catalog, listing an empty catalog, listing a partially
   full catalog, listing a completely full catalog

   In general, you want to test valid configurations, invalid
   configurations, and all boundary cases

   @author krodgers

   DO NOT MODIFY
 */
public class CatalogTest {

    @Test
    public void testAddBook(){
	Catalog shelf = new Catalog();
	Book testBook = new Fiction("1234567890123", "Test Author", "Test Title", "Sci-Fi");

	assertEquals(shelf.addBook(testBook), "Test Title");
    }

    @Test
    public void testAddBookFullCatalog(){
	Catalog shelf = new Catalog();

	// Add five books
	for(int i = 100; i < 105; i++){
	    shelf.addBook(new Fiction(String.valueOf(i), "author", "title", "genre"));
	}

	// Add sixth invalid book
	Book testBook = new Fiction("1234567890123", "Test Author", "Test Title", "Sci-Fi");
	
	assertNull(shelf.addBook(testBook));

    }

    @Test
    public void testListCatalogEmptyCatalog(){
	Catalog shelf = new Catalog();
	assertEquals(shelf.listCatalog(), "");
    }

    @Test
    public void testListCatalog(){
	Catalog shelf = new Catalog();
	String expected = "";
	
	for(int i = 100; i < 103; i++){
	    shelf.addBook(new Reference(String.valueOf(i), "author", "title", "subject"));
	    expected += i + ", ";
	}
	
	assertEquals(shelf.listCatalog(), expected);
    }

    @Test
    public void testListCatalogFullCatalog(){
	Catalog shelf = new Catalog();
	String expected = "";
	
	for(int i = 100; i < 105; i++){
	    shelf.addBook(new Reference(String.valueOf(i), "author", "title", "subject"));
	    expected += i + ", ";
	}
	assertEquals(shelf.listCatalog(), expected);
    }

       
}

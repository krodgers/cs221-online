package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
   Tests the Reference class
   Write methods to ensure every method of Reference works as intended
   
   @author TODO
*/

public class ReferenceTest {
    
    
}

public class HelloWorld{

  
    /**
     * Main entry point.
     * @param args
     */
    public static void main(String args[]){

        //Fix the compiler error below and run the program to make sure you have everything
        //installed and working!
        System.out.println("It Works!")
    }
}

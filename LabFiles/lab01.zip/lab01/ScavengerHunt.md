# Scavenger Hunt

Complete each section below! Replace each TODO with the correct information.
For the URLS, copy/paste the URL from the address bar of your browser.


## About Me

- Name: TODO
- Boise state username: TODO


## Course Links

- Syllabus URL: TODO
- Text Book URL: TODO
- Discussion Forum URL: TODO
- Office Hours URL: TODO

## Documents

- Class coding Standards URL: TODO
- VSCode Set Up Instructions URL: TODO
- Submitting to Onyx URL (either Windows or Mac): TODO

## Syllabus Stuff

- Late work can be submitted TODO days late
- One TODO can be submitted up to 48 hours late without penalty.

## Semester Study Plan

For this section, list the days and times you intend to work on this
class.  Remember you should be spending 9 - 12 hours per week on this
course.  Your time is best spent spread over several days.

The first row is filled out as an example; delete the first row in
your final submission.


Day			| Time
------ 	 		| -----
Example: Tuesday	| 2:30 pm - 4:00 pm
	 		|
			|
			|
			|
			|
			|

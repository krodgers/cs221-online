# Lab 9: An ArrayList ADT

## Learning Objectives

- Implement generic methods and classes
- Implement a List abstract data type (ADT)  backed by an array
- Confirm correct implementations of List ADT with testing
- Implement a List iterator for a List abstract data type
- Establish the practice/habit of understanding
  expectations/requirements of all units of code BEFORE writing that
  code.
- Apply test driven development and debugging in development of data struc



## Overview

This project contains the following source files:

- TheList.java - Interface defining the public interface for lists. Do
  not modify this file.

- TheArrayList.java - a list that implements TheList interface using
  an array as the underlying data structure. It is partially
  implemented; you need to implement the rest of this file. Do not
  change the public interface or add instance variables.  You may add
  private helper methods as needed (though you probably won't need
  to).

the following test files:

- TheListTest.java - contains tests that will test any list that
  implements TheList.  Use the example tests as a guide for creating
  the remaining tests.


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
`./gradlew build`

From a windows terminal, run
`start gradlew.bat build`


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Testing
This project does NOT have a main method.  To test your list, use

`./gradlew test`

To test this project on Windows:
`start gradlew.bat test`



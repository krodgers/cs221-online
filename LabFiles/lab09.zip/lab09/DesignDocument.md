# Design Document

- name: TODO

## Tasks

## Tests List all test cases.

You need to list the options for each method. We want to test every
single method on an empty list, a list with one element, a list with
two elements (so we have a first and last), and a list with three
elements (the smallest list with a middle element).

For each method, you want to test valid and invalid data.

For now, don't worry about testing the iterator.

### Tests Starting with an empty list
[] add to front A --> [A]
[] add to back A -- > [A]
[] add A --> [A]
[] add B after A --> NoSuchElementException
[] add B before A--> NoSuchElementException
[] add A at index 0 --> [A]
[] add A at index 1 --> IndexOutOfBoundsException
[] removeFront --> NoSuchElementException
[] removeBack --> NoSuchElementException
[] remove A --> NoSuchElementException
[] remove 0 --> NoSuchElementException
[] update index 0 to contain A --> NoSuchElementException
[] get 0 --> NoSuchElementException
[] find A --> -1
[] first --> NoSuchElementException
[] last --> NoSuchElementException
[] clear --> size() should return 0
[] size --> 0
[] toString --> "[ ]"


### Tests Starting with a one element list
[A] add to front B --> [B, A]
[A] add to back B -- > [A, B]
[A] add B --> [A, B]
[A] add B after A --> [A, B]
[A] add C after B --> NoSuchElementException


[A] toString --> "[A, ]"



### Tests Starting with a two element  list


### Tests Starting with a three element list

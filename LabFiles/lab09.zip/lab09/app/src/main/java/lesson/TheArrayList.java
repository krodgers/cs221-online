package lesson;

import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Array-based implementation of TheList 
 *
 * An Iterator with working * hasNext and next methods is implemented,
 * but ListIterator is * unsupported.
 * 
 * @author 
 *
 * @param <T> type to store
 */
public class TheArrayList<T> implements TheList<T> {
    private static final int DEFAULT_CAPACITY = 15;
    private static final int NOT_FOUND = -1;
	
    private T[] data;
    private int rear;

	
    /** Creates an empty list with default initial capacity */
    public TheArrayList() {
	this(DEFAULT_CAPACITY);
    }
	
    /** 
     * Creates an empty list with the given initial capacity
     * @param initialCapacity
     */
    @SuppressWarnings("unchecked")
    public TheArrayList(int initialCapacity) {
	data = (T[])(new Object[initialCapacity]);
	rear = 0;
    }
	
    /** Double the capacity of data */
    private void expandCapacity() {
	data = Arrays.copyOf(data, data.length*2);
    }

    @Override
    public void addFront(T element) {
	// TODO 
		
    }

    @Override
    public void addBack(T element) {
	// TODO 
		
    }

    @Override
    public void add(T element) {
	// TODO 
		
    }

    @Override
    public void addAfter(T element, T target) {
	// TODO 
		
    }

    @Override
    public void addBefore(T element, T target) {
	// TODO 
		
    }

    @Override
    public void add(int index, T element) {
	// TODO 
		
    }

    @Override
    public T removeFront() {
	// TODO 
	return null;
    }

    @Override
    public T removeBack() {
	// TODO 
	return null;
    }

    @Override
    public T remove(T element) {
	int index = find(element);
	if (index == NOT_FOUND) {
	    throw new NoSuchElementException();
	}
		
	T retVal = data[index];
		
	rear--;
	//shift elements
	for (int i = index; i < rear; i++) {
	    data[i] = data[i+1];
	}
	data[rear] = null;
			
	return retVal;
    }

    @Override
    public T remove(int index) {
	// TODO 
	return null;
    }

    @Override
    public void update(int index, T element) {
	// TODO 
		
    }

    @Override
    public T get(int index) {
	if(rear == 0 || index >= rear || index < 0)
		throw new NoSuchElementException();
	return data[index];
    }

    @Override
    public int find(T element) {
	int index = NOT_FOUND;
		
	if (rear > 0) {
	    int i = 0;
	    while (index == NOT_FOUND && i < rear) {
		if (element.equals(data[i])) {
		    index = i;
		} else {
		    i++;
		}
	    }
	}
		
	return index;
    }

    @Override
    public T first() {
	// TODO 
	return null;
    }

    @Override
    public T last() {
	// TODO 
	return null;
    }

    @Override
    public void clear() {
	data = (T[])(new Object[data.length]);
	rear = 0;
    }

    @Override
    public int size() {
	// TODO 
	return 0;
    }

    @Override
    public Iterator<T> iterator() {
	return new TheIterator();
    }

    @Override
    public ListIterator<T> listIterator() {
	throw new UnsupportedOperationException();
    }

    @Override
    public ListIterator<T> listIterator(int startingIndex) {
	throw new UnsupportedOperationException();
    }

    /** Iterator for TheArrayList */
    private class TheIterator implements Iterator<T> {
	private int nextIndex;
		
	public TheIterator() {
	    nextIndex = 0;
	}

	@Override
	public boolean hasNext() {
	    // TODO 
	    return false;
	}

	@Override
	public T next() {
	    // TODO 
	    return null;
	}
		
    }
}

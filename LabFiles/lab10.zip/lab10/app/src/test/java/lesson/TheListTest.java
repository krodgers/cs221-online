package lesson;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import static org.testng.Assert.*;

import java.lang.IllegalArgumentException;
import java.util.NoSuchElementException;
import java.util.Iterator;

/**
 * Tests TheList Objects
 * 
 * @author 
 */


public class TheListTest {

    // Determine type of list being used
    //private final String LIST_TYPE = "ArrayList";
    private final String LIST_TYPE = "SinglyLinkedList";

    // List values
    private final Integer ELEM_A = 1;
    private final Integer ELEM_B = 2;
    private final Integer ELEM_C = 3;
    private final Integer ELEM_D = 4;
    private final Integer INVALID_ELEM = -3;
    

    // Define more arrays as needed
    private final Integer[] EMPTY = new Integer[0];
    private final Integer[] A = new Integer[]{ELEM_A};
    private final Integer[] B = new Integer[]{ELEM_B};
    private final Integer[] C = new Integer[]{ELEM_C};
    private final Integer[] D = new Integer[]{ELEM_D};
    
    private final Integer[] AB = new Integer[]{ELEM_A, ELEM_B};
    private final Integer[] ABC = new Integer[]{ELEM_A, ELEM_B, ELEM_C};
    private final Integer[] AD = new Integer[]{ELEM_A, ELEM_D};
    private final Integer[] ABD = new Integer[]{ELEM_A, ELEM_B, ELEM_D};
    private final Integer[] ABCD = new Integer[]{ELEM_A, ELEM_B, ELEM_C, ELEM_D};

    private final Integer[] DA = new Integer[]{ELEM_D, ELEM_A};
    private final Integer[] DAB = new Integer[]{ELEM_D, ELEM_A, ELEM_B};
    private final Integer[] DABC = new Integer[]{ELEM_D, ELEM_A, ELEM_B, ELEM_C};
    
    

    /**
     * Returns TheList object containing the elements contained in elems.
     *
     * This method depends on addFront(elem) working correctly.
     *
     * @param elems - the elements to add to the list
     *                should be one of the array constants defined above
     *
     * @return a TheList object as determined by LIST_TYPE containing the
     *           elements in elems in the same order
     */
    private TheList<Integer> getList(Integer[] elems){
	TheList<Integer> list = null;
	switch(LIST_TYPE){
	case "ArrayList":
	    //	    list = new TheArrayList<Integer>();
	    break;
	case "SinglyLinkedList":
	    list = new TheSinglyLinkedList<Integer>();
	    break;
	default:
	    throw new IllegalArgumentException("List type must be ArrayList or SinglyLinkedList");
	}
	

	for(int i = elems.length - 1; i >= 0; i--){
	    list.addFront(elems[i]);
	}

	return list;	
    }


    /**
     * Verifies actual and expected are the same size and contain the same
     * elements in the same order.
     *
     * Depends on size() and get() working correctly to accurately determine
     * if the lists are equal
     *
     * @param 
     * @return true iff actual and expected have the same elements in the same order
     *
     */
    private boolean areEqual(TheList<Integer> actual, Integer[] expected){
	if(actual.size() != expected.length)
	    return false;

	int size = expected.length;
	for(int i = 0; i < size; i++){
	    if(!actual.get(i).equals(expected[i]))
		return false;
	}
	return true;	    
    }





    //////////////////////////////////////////////
    // Data Provider that simply provides lists //
    // Can be used in invalid tests and some    //
    // utility tests                            //
    //////////////////////////////////////////////
	
    /**
       Creates an empty list, 1 element list, 2 element list, and 3
       element list
    */
    @DataProvider(name = "sizedLists")
    public Object[][] getLists() {
	// Creates a 2D array - an array of arrays
	// the first object is the starting list,
	return new Object[][] {{getList(EMPTY)},// test data 1
			       {getList(A)}, //test data 2
			       {getList(AB)}, // test data 3
			       {getList(ABC)}, // test data 4
	};
    }


    ///////////////////
    // Test addFront //
    ///////////////////
    /**
       Creates lists and expected values for addToFrontTest
    */
    @DataProvider(name = "addFrontProvider")
    public Object[][] getAddFrontList() {
	// Creates a 2D array - an array of arrays
	// the first object is the starting list,
	// the second object is the expected list
	return new Object[][] {{getList(EMPTY), D}, // test data 1
			       {getList(A), DA}, // test data 2
			       {getList(AB), DAB}, // test data 3
			       {getList(ABC),DABC} // test data 4
	};
    }
	
    /** 
	Test addFront

	This method is called once for every set of data
	contained in the array generated from 'addFrontProvider'.
    */ 
    @Test(dataProvider = "addFrontProvider")
    public void testAddFront(TheList<Integer> startList, Integer[] expected){
	// call addFront on startList
	startList.addFront(ELEM_D);
	// check that startList is now the same as the expected list
	assertTrue(areEqual(startList, expected));
    }



    
    //////////////////////////
    // Test addBack and add //
    //////////////////////////
    
    /**
       Creates lists and expected values for TestAddBack and TestAdd
    */
    @DataProvider(name = "addBackProvider")
    public Object[][] getAddBackList() {
	// Creates a 2D array - an array of arrays
	// the first object is the starting list,
	// the second object is the expected list
	return new Object[][] {{getList(EMPTY), D}, // test data 1
			       {getList(A), AD}, // test data 2
			       {getList(AB), ABD}, // test data 3
			       {getList(ABC), ABCD} // test data 4
	};
    }
	
    /** 
	Test addBack

	This method is called once for every set of data
	contained in the array generated from 'addBackProvider'.
    */ 
    @Test(dataProvider = "addBackProvider")
    public void testAddBack(TheList<Integer> startList, Integer[] expected){
	// call addBack on startList
	startList.addBack(ELEM_D);
	// check that startList is now the same as the expected list
	assertTrue(areEqual(startList, expected));
    }

    /** 
	Test add
	
	This method is called once for every set of data
	contained in the array generated from 'addBackProvider'.

	Since the expected values for both addBack and add are the
	same, use the same dataProvider
    */ 
    @Test(dataProvider = "addBackProvider")
    public void testAdd(TheList<Integer> startList, Integer[] expected){
	// call add on startList
	startList.add(ELEM_D);
	// check that startList is now the same as the expected list
	assertTrue(areEqual(startList, expected));
    }


    ///////////////////
    // Test addAfter //
    ///////////////////
    

    
    ///////////////////////////
    // Test addBefore	 //
    ///////////////////////////


    
    //////////////////////////////
    // Test add at index	    //
    //////////////////////////////


    /////////////////////////////
    // Test removeFront	   //
    /////////////////////////////

    
    
    
    ////////////////////////////
    // Test removeBack	  //
    ////////////////////////////

    
    /////////////////////////////////////////
    // Test remove specific element	       //
    /////////////////////////////////////////

    
    ///////////////////////////////////////
    // Test remove specific index	     //
    ///////////////////////////////////////

    
    ////////////////////////
    // Test update	      //
    ////////////////////////

    
    ////////////////////////
    // Test get	      //
    ////////////////////////

    
    //////////////////////
    // Test find	    //
    //////////////////////

    
    
    ///////////////////////
    // Test first	     //
    ///////////////////////

    
    //////////////////////
    // Test last	    //
    //////////////////////

   
    
    
    ///////////////////////
    // Test clear	     //
    ///////////////////////

    
    //////////////////////
    // Test size	    //
    //////////////////////
    
    

    //////////////////////////
    // Test toString        //
    //////////////////////////
    /**
       Creates lists and expected values for toString
    */
    @DataProvider(name = "toStringLists")
    public Object[][] gettoStringList() {
	// Uses regular expressions to test for matches
	return new Object[][] {{getList(EMPTY), "\\[ ?\\]"}, // [ ]
			       {getList(A), "\\[ ?1,? ?\\]"}, // [1, ] or [1]
			       {getList(AB), "\\[ ?1, ?2,? ?\\]"}, //[1, 2, ] or [1, 2] or [1,2]
			       {getList(ABC), "\\[ ?1, ?2, ?3,? ?\\]"}, // [1, 2, 3, ] or [1, 2, 3] or [1,2,3]
	};
    }

    
    /**
       Test toString
     */
    @Test(dataProvider = "toStringLists")
    public void testToString(TheList<Integer> startList, String expected){
	String actual = startList.toString().trim();
	assertTrue(actual.matches(expected));
    }
	
    
    //////////////////////////////////////////////////////////////////////
    // Tests invalid method calls that result in Exceptions             //
    //////////////////////////////////////////////////////////////////////
    
    /**
       Test invalid addAfter calls
       Expects all calls to throw NoSuchElementException
    */
    @Test(dataProvider = "sizedLists",
	  expectedExceptions = NoSuchElementException.class)
	  public void testInvalidAddAfter(TheList<Integer> startList){
	// call addAfter on startList 
	startList.addAfter(ELEM_D, INVALID_ELEM);
    }

    /**
       Test invalid addBefore calls
       Expects all calls to throw NoSuchElementException
    */
    @Test(dataProvider = "sizedLists",
	  expectedExceptions = NoSuchElementException.class)
	  public void testInvalidAddBefore(TheList<Integer> startList){
	// call addAfter on startList 
	startList.addBefore(ELEM_D, INVALID_ELEM);
    }


    /**
       Test invalid add at index
    */
    @DataProvider(name = "IndexInvalid")
    public Object[][] getIndexInvalid() {
	return new Object[][] {
	    {getList(EMPTY), 1},
	    {getList(A), -1},
	    {getList(A), 2},
	    {getList(AB), -1},
	    {getList(AB), 3},
	    {getList(ABC), -1},
	    {getList(ABC), 4},
	};
    }
    
    @Test(dataProvider = "IndexInvalid",
	  expectedExceptions = IndexOutOfBoundsException.class)
	  public void testInvalidAddAt(TheList<Integer> startList, int idx){
	// call add
	startList.add(idx, INVALID_ELEM);
    }
    

    /**
       Test invalid remove specific element
    */

    
   
    /**
       Test invalid removeFront
    */



    /**
       Test invalid removeBack
    */



    /**
       Test invalid remove index
    */


    /**
       Test invalid update
    */


    /**
       Test invalid get
    */


    /**
       Test invalid first
    */

    /**
       Test invalid last
    */

    
    ////////////////////
    // Test Iterators //
    ////////////////////

    /**
       Generates data in the form
       {iterator, number of valid calls, expected contents of list}

       The list should not be modified by the iterator
     */
    @DataProvider(name = "iterData")
    public Object[][] getIterData() {

	return new Object[][] {
	    {getList(EMPTY).iterator(), 0, EMPTY},
	    {getList(A).iterator(), 1, A},
	    {getList(AB).iterator(), 2, AB},
	    {getList(ABC).iterator(), 3, ABC},
	};
    }
    
    
    /**
       Tests the iterator can make it through the list the expected
       number of times and correctly throws NoSuchElementException
       when it runs out of elements


       @param expectedNextSuccesses - number of times next() can successfully be called on iter
                           expectedNextSuccesses + 1 should result in NoSuchElementException 
     */
    @Test(dataProvider = "iterData")
    public void testIterator(Iterator<Integer> iter, int expectedNextSuccesses, Integer[] expectedNext){
	// verify iterator gets through all expected valid calss
	for(int i = 0; i < expectedNextSuccesses; i++){
	    assertTrue(iter.hasNext());
	    assertEquals(iter.next(), expectedNext[i]);
	}

	// verify invalid iterator behaves correctly
	assertFalse(iter.hasNext());
	assertThrows(NoSuchElementException.class, () -> {iter.next();});
    }
}

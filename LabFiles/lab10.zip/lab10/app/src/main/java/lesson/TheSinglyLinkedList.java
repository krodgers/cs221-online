package lesson;

import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.ListIterator;

/**
 * Single-linked node implementation of TheList.
 * An Iterator is implemented, but ListIterator is unsupported.
 * 
 * @author
 * 
 * @param <T> type to store
 */

public class TheSinglyLinkedList<T> implements TheList<T> {

    private Node<T> head;
    private Node<T> tail;
    private int size;

    /** Creates an empty list */
    public TheSinglyLinkedList() {
	head = tail = null;
	size = 0;
    }

    @Override
    public void addFront(T element) {
	// create new node
	Node<T> newHead = new Node<T>(element);

	// set node's next to point to current head
	newHead.setNext(head);

	// update head
	head = newHead;

	// if this is the first node in the list
	// head and tail point to same node
	if (size == 0)
	    tail = head;

	// update size
	size++;
    }

    @Override
    public void addBack(T element) {
	// TODO

    }

    @Override
    public void add(T element) {
	// TODO
    }

    @Override
    public void addAfter(T element, T target) {
	// TODO
    }

    @Override
    public void addBefore(T element, T target) {
	// TODO
    }

    @Override
    public void add(int index, T element) {
	// TODO
    }

    @Override
    public T removeFront() {
	// check there are nodes to remove
	if (size == 0)
	    throw new NoSuchElementException();

	// store value to return
	T val = head.getElement();

	if (size == 1) {
	    // list only contains a single node
	    // head and tail point to the same node
	    // head.next() would be null
	    head = tail = null;
	} else
	    head = head.getNext(); // update head

	// update size
	size--;

	// return removed value
	return val;
    }

    @Override
    public T removeBack() {
	// TODO
	return null;
    }

    @Override
    public T remove(T element) {
	if (size == 0) {
	    throw new NoSuchElementException();
	}

	boolean found = false;
	Node<T> previous = null;
	Node<T> current = head;

	while (current != null && !found) {
	    if (element.equals(current.getElement())) {
		found = true;
	    } else {
		previous = current;
		current = current.getNext();
	    }
	}

	if (!found) {
	    throw new NoSuchElementException();
	}

	if (size() == 1) { // only node
	    head = tail = null;
	} else if (current == head) { // first node
	    head = current.getNext();
	} else if (current == tail) { // last node
	    tail = previous;
	    tail.setNext(null);
	} else { // somewhere in the middle
	    previous.setNext(current.getNext());
	}

	size--;

	return current.getElement();
    }

    @Override
    public T remove(int index) {
	// TODO
	return null;
    }

    @Override
    public void update(int index, T element) {
	// TODO
    }

    @Override
    public T get(int index) {
	// TODO
	return null;
    }

    @Override
    public int find(T element) {
	// TODO
	return -1;
    }

    @Override
    public T first() {
	// TODO
	return null;
    }

    @Override
    public T last() {
	// TODO
	return null;
    }

    @Override
    public void clear() {
	// TODO
    }

    @Override
    public int size() {
	// TODO
	return -1;
    }

    @Override
    public String toString() {
	return null;
    }

    @Override
    public Iterator<T> iterator() {
	return new SLLIterator();
    }

    @Override
    public ListIterator<T> listIterator() {
	throw new UnsupportedOperationException();
    }

    @Override
    public ListIterator<T> listIterator(int startingIndex) {
	throw new UnsupportedOperationException();
    }

    /** Iterator for TheSinglyLinkedList */
    private class SLLIterator implements Iterator<T> {
	private Node<T> nextNode;

	/** Creates a new iterator for the list */
	public SLLIterator() {
	    nextNode = head;
	}

	@Override
	public boolean hasNext() {
	    // TODO
	    return false;
	}

	@Override
	public T next() {
	    // TODO
	    return null;
	}

    }
}

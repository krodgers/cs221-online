# Design Document

- name:

## Iterator Expectations

List the expected return values for calling next() and hasNext() on an
iterator of lists with sizes 0, 1, 2, and 3. The expected return
values for sizes 0 and 1 are given as examples.

Results are listed in the form

<list> - <method(s) called on the iterator> - <return value from last method call>


You should continue to call next() until you end up with a
NoSuchElementException and hasNext() until it returns false.

### Iterator results starting with an empty list
[] - next() - NoSuchElementException
[] - hasNext() - false


### Iterator results starting with a one-element list
[A] - next() - A
[A] - next();next() - NoSuchElementException
[A] - hasNext() - true
[A] - hasNext();next();hasNext() - false



### Iterator results starting with a two-element list



### Iterator results starting with a three-element list

# Lab 10: A Singly-Linked List ADT

## Learning Objectives

- Implement generic methods and classes
- Implement a List abstract data type (ADT)  backed by nodes
- Confirm correct implementations of List ADT with testing
- Implement a List iterator for a List abstract data type
- Establish the practice/habit of understanding
  expectations/requirements of all units of code BEFORE writing that
  code.
- Apply test driven development and debugging in development of data structures



## Overview

This project contains the following source files:

- TheList.java - Interface defining the public interface for lists. Do
  not modify this file.

- TheSinglyLinkedList.java - a list that implements TheList interface
  using nodes as the underlying data structure. It is partially
  implemented; you need to implement the rest of this file. Do not
  change the public interface or change or add instance variables.
  You may add private helper methods as needed (though you probably
  won't need to).
  
- Node.java - Node class to be used as the Nodes in
  TheSinglyLinkedList.  Do not modify.


the following test files:

- TheListTest.java - contains some tests along with iterator tests and
  comments describing tests you should add.  It's basically the same
  file from the last project, but check it against your tests to make
  sure you're covering all the test cases.  Copy the iterator test
  into your test file.


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
`./gradlew build`

From a windows terminal, run
`start gradlew.bat build`


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Testing
This project does NOT have a main method.  To test your list, use

`./gradlew test`

To test this project on Windows:
`start gradlew.bat test`



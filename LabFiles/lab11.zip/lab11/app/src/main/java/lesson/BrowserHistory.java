package lesson;

/**
 * Class that represents a browser back button using a Doubly-Linked
 * List
 *
 * @author
 */

public class BrowserHistory<T> implements HistoryInterface<T> {

    // instance variables
    private DLLNode<T> head;
    private DLLNode<T> tail;
    private int size;

    /**
     * Constructor
     */
    public BrowserHistory() {
        head = tail = null;
        size = 0;
    }

    /**
     * Returns a reference to head
     * 
     * Used for testing purposes only!!
     */
    public DLLNode<T> getHead() {
        return head;
    }

    /**
     * Returns a reference to tail
     * 
     * Used for testing purposes only!!
     */
    public DLLNode<T> getTail() {
        return tail;
    }

}

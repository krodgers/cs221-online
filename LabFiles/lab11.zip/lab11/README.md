# Lab 11: DLL Stack Back Button

## Learning Objectives

- Implement generic methods and classes
- Implement a List abstract data type (ADT)  backed by nodes
- Confirm correct implementations of List ADT with testing
- Apply test driven development and debugging in development of data structures


## Overview

This project contains the following source files:

- HistoryInterface.java - interface for an object that keeps track of
  history that can be unwound (like a browser back button, an undo
  button, traversing back up a file tree, etc). Do not modify this
  file.

- BrowserHistory.java - class you will implement.  Implements
  HistoryInterface using a Doubly Linked List as a stack.  You can use
  either the head or the tail as the top of the stack.

- DLLNode.java - Node class to be used as the Nodes in
  BrowserHistory.  Do not modify.


the following test files:

- BrowserHistoryTest.java - contains some tests for
  BrowserHistory. Feel free to add more.

## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
`./gradlew build`

From a windows terminal, run
`start gradlew.bat build`


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Testing
This project does NOT have a main method.  To test your list, use

`./gradlew test`

To test this project on Windows:
`start gradlew.bat test`



# Design Document

- name:

## DLL Stack Design

In this document, specify how you plan to implement your stack.

- Which end are you using as the top of your stack? Why?

- Given your top of the stack, when you `push` an element, will that
  element be the new head or tail? Which instance variables do you
  need to update when you `push`?

- Given your top of the stack, when you `pop` an element, will you
  remove the head or tail? Which instance variables do you need to
  update when you `pop`?

- List the steps you need to take in `removeFromHistory`. Make sure
  you list each specific step of your algorithm such that someone else
  could draw a DLL, follow the steps you've listed here, and end up
  with the correct list.



## Testing the DLL Stack

Given each of the following stacks, state the return value (if one
exists) and what the stack looks like after each of the methods is
called.

The notation for the stack is:
[A, B, C]

where A is at the top of the stack and C is at the bottom of the stack.

The notation for the tests is:
<method call> --> <return value or exception thrown or nothing if there is no return value>; <resulting stack>

The results of calling methods using an empty stack is given as an
example.


# Empty Stack
Stack: []
- push(A) --> [A]
- pop() --> NoSuchElementException; []
- firstVisited() --> NoSuchElementException; []
- lastVisited() -->  NoSuchElementException; []
- getHistory(true) --> ""; []
- getHistory(false) --> ""; []
- removeFromHistory(A) --> false; []
- size() --> 0; []
- toString() --> "[History(0): ]"


# One Element Stack
Stack: [A]
- push(B) --> 
- pop() --> 
- firstVisited() --> 
- lastVisited() -->  
- getHistory(true) -->
- getHistory(false) -->
- removeFromHistory(A) -->
- size() --> 
- toString() --> 


# Two Element Stack
Stack: [A, B]
- push(C) --> 
- pop() --> 
- firstVisited() --> 
- lastVisited() -->  
- getHistory(true) -->
- getHistory(false) -->
- removeFromHistory(A) -->
- removeFromHistory(C) -->
- size() --> 
- toString() --> "[History(2): A]"; [A, B]


# Duplicated Item Stack
Stack: [A, B, C, A, B, B, C]
- push(D) --> 
- pop() --> 
- firstVisited() --> 
- lastVisited() -->  
- getHistory(true) -->
- getHistory(false) -->
- removeFromHistory(B) -->
- removeFromHistory(C) -->
- size() --> 
- toString() --> 



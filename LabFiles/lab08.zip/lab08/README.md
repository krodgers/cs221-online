# Lab 8: ScheduleMaker - Course Saga Part 3

## Learning Objectives

- Use generic methods and classes
- Understand generic classes
- Write exception safe code
- Apply using the try/catch keywords
- Identify methods that have side effects and how that impacts testability
- Understand how to use a debugger


## Overview

This project contains the following source files:

- App.java - Driver class; Uses several data structures to use when
  calling ScheduleMaker methods. Explores different ways to invoke an
  iterator; partially implemented, you need to finish the rest.

- ScheduleMaker.java - contains methods for parsing and printing a
  collection of CreditCourses.  All data is accessed by using an
  iterator.  You need to implement these methods.

the following test files:

- CreditCourseTest.java - contains complete tests for
  CreditCourse.java; do not modify. Do look through the tests to see
  what is being tested, how the tests are structured, etc.

- ScheduleMakerTest.java - contains complete tests for
  ScheduleMaker. Look through the code - it contains examples of
  defining test cases and how to formalize expectations and several
  examples of using iterators.  Do not modify the file.


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run this project on *nix system:
./gradlew run

To run this project on Windows:
start gradlew.bat run


This will run the main method contained in App.java
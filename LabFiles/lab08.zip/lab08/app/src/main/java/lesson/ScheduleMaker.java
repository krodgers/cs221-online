package lesson;

import java.util.Iterator;
import java.util.ArrayList;

/**
   Utility class that generates a String representation of a course
   schedule or creates a collection of CreditCourses from a collection
   of Strings.

   @author TODO
*/
public class ScheduleMaker{

    /**
       Returns a string of the course schedule in the form

       Full Schedule
       -------------
       <dept> <course number>
       <dept> <course number>

       @param iter - an iterator over a collection of CreditCourses to print
       @return String listing all courses from the iterator
       
    */
    public static String getScheduleStr(Iterator<CreditCourse> iter){
	String res = "Full Schedule\n-------------\n";


	return res;
    }


    /**
       Parses and creates CreditCourses from Strings. Each String
       should be in the format <courseNo> <credits> <dept>.

       You should catch NumberFormatException. You don't have to do anything with it except skip that String.

       @param iter - an iterator over Strings in the format <courseNo> <credits> <dept>
       @return an ArrayList of CreditCourse objects created from the Strings
    */

    public static ArrayList<CreditCourse> parseSchedule(Iterator<String> iter){
	return null;
    }

}

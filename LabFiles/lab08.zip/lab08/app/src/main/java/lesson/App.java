package lesson;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Queue;
import java.util.LinkedList;

/**
 * Uses several kinds of data structures to print and parse schedules 
 * 
 * @author krodgers
 * @author TODO
 */


public class App {
    
    
    public static void main(String[] args) {
	// Define courses to be used
	CreditCourse[] courses = {new CreditCourse("EDU", 100, 2),
				  new CreditCourse("EDU", 101, 2),
				  new CreditCourse("EDU", 102, 2),
				  new CreditCourse("EDU", 103, 2),
				  new CreditCourse("HIST", 200, 2),
				  new CreditCourse("HIST", 204, 2)
	};


	// ArrayList of Credit Courses
	ArrayList<CreditCourse> arrCourse = new ArrayList<CreditCourse>();
	for(CreditCourse course : courses)
	    arrCourse.add(course);
	
	// HashSet of Credit Courses 
	HashSet<CreditCourse> setCourse = new HashSet<CreditCourse>(arrCourse);
	
	// Queue of Credit Courses
	Queue<CreditCourse> queCourse = new LinkedList<CreditCourse>(arrCourse);
	

	// Docs: https://docs.oracle.com/javase/8/docs/api/java/util/ArrayList.html
	// https://docs.oracle.com/javase/8/docs/api/java/util/HashSet.html
	// https://docs.oracle.com/javase/8/docs/api/java/util/Queue.html

	// TODO: for each of the data structures defined above, 
	// create and pass an iterator to ScheduleMaker.getScheduleStr
	// Print out the result
	System.out.println("ArrayList: ");


	System.out.println("HashSet: ");


	System.out.println("Queue: ");

	

	// Part Two
	
	// Create data to be parsed
	LinkedList<String> listCourse = new LinkedList<String>();
	listCourse.add("100 4 EDU");
	listCourse.add("345 2 HIST");
	listCourse.add("146 3 SOC");
	listCourse.add("602 1 ENG");
	listCourse.add("103 1 CSE");
	listCourse.add("246 2 INMX");

	// uncomment and mix in the following add statement to test your exception handling in parseSchedule
	// the output should not change
	// listCourse.add("not numbers EDU");
		
	// TODO: create an iterator for listCourse and pass it to ScheduleMaker.parseSchedule
	// Don't forget to store the return value



	// Print the return value from parseSchedule THREE times, three DIFFERENT ways

	// TODO: Print (1): Use an enhanced for loop (for-each loop) to print each item
	// use enhanced for loop to print, use while loop to print,
	// pass iterator to getScheduleStr to print
	System.out.println("Enhanced For Loop: ");

	// TODO: Print (2): Create an iterator for the ArrayList.  Use
	// the iterator and a while loop to print each element of the
	// ArrayList.  Use hasNext() and next() methods
	System.out.println("\nWhile Loop + Iterator");


	// TODO: Print (3): Create an iterator for the ArrayList. (you
	// can use the one you made above, just make sure you
	// reinitialize it because at this point, the iterator is at
	// the end of the ArrayList). Pass the iterator to
	// getScheduleStr and print that String
	System.out.println("\nIterator + getScheduleStr");

	
	
    }

    
}

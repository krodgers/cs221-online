package lesson;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;

/**
 * Reads in course data from the user, then prints in sorted order
 *
 * @author
 */


public class App {

    public static void main(String[] args) {
	// Read in the data
	ArrayList<CreditCourse> courses = getData();

	// TODO: Implement getDataPieces and replace above call with a call to getDataPieces

	
	// Print unsorted data
	// TODO: Replace loop below with call to matchingDepts
	// Remember it returns a string, so you have to print that string
	for(CreditCourse course : courses){
	    System.out.println(course);
	}

	// Sort data
	// Data is sorted in place
	Collections.sort(courses);
	
	// Print sorted data
	System.out.println();
	for(CreditCourse course : courses){
	    System.out.println(course);
	}
	
    }

    /**
     * Reads data from user in the format
     * department courseNo numCredits
     *
     * Reads until the user enters a blank line
     * @return ArrayList containing CreditCourses created from user data
     */
    private static ArrayList<CreditCourse> getData(){
	ArrayList<CreditCourse> courses = new ArrayList<CreditCourse>();
	System.out.println("Start entering data like: dept courseNo credit");
			   
	Scanner kbd = new Scanner(System.in);
	try {
	    String line = kbd.nextLine();
	    while(!line.isEmpty()){
		Scanner lineScan = new Scanner(line);
		String dept = lineScan.next();
		int num = lineScan.nextInt();
		int credits = lineScan.nextInt();
		
		lineScan.close();
		courses.add(new CreditCourse(dept, num, credits));
		line = kbd.nextLine();
	    }
	} catch(InputMismatchException e){
	    System.out.println("Entered wrong data. Usage: dept courseNo credits");
	} catch(NoSuchElementException  e){
	    System.out.println("Didn't enter enough data. Usage: dept courseNo credits");
	} finally{
	    kbd.close();
	}
	return courses;
    }

    /**
     * Reads course data from user by asking for all departments, all
     * course numbers, and all credits
     *
     * Example input:
     * CS CE
     * 100 104
     * 3 6
     *
     * Example returns an ArrayList with two CreditCourses - "CS 100 (3)" and "CE 104 (6)"
     *
     * @return ArrayList containing CreditCourses created from user data
     */
    private static ArrayList<CreditCourse> getDataPieces(){
	return null;
    }
    
    /**
     * Returns a string that prints a course, followed by a list of
     * all other courses in the same department
     */
    private static String matchingDepts(ArrayList<CreditCourse>){
	return null;
    }


    
}

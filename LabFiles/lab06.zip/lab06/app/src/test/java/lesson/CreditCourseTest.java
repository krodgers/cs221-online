package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
 * Tests CreditCourse Object
 * Write at least one test method per class method
 * @author
 */


public class CreditCourseTest {

    //TODO: Write your tests!

    /**
     * Write a summary of what this test tests
     * This is an example. Delete this method.
     */
    @Test
    public void descriptiveNameTest(){
	assertEquals("actual", "expected");
    }
}

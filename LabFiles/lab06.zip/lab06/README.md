# Lab 6: CreditCourse - Course Saga Part 1

## Learning Objectives

- Introduce the comparable Interface
- Use generic methods and classes
- Understand basic algorithm analysis


## Overview

This project contains the following source files:

- App.java - Driver class; creates ArrayList of CreditCourse using
  	     data entered by the user. It's partially implemented; finish
	     implementing the remaining methods as the last part of this lab
- CreditCourse.java - class representing a course taken for credit;
  		      implements Comparable interface. You need to
  		      implement this class.


and the following test files:

- CreditCourseTest.java - will contain tests for CreditCourse objects;
  		       	 needs to be fully implemented


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run this project on *nix system:
./gradlew run

To run this project on Windows:
start gradlew.bat run


This will run the main method contained in App.java
lspackage lesson;

/**
 * Represents a course associated with a number of credits
 *
 * @author
 */

public class CreditCourse implements Comparable<CreditCourse> {

    // Instance Variables


    // Constructors
    
    /**
     * Constructor - Creates course with department dept, course
     * number number, and zero credits
     *
     * @param dept - the department in which this course belongs
     * @param number - the number of this course
     */
    CreditCourse(String dept, int number){


    }


    /**
     * Constructor - Creates course with department dept, course
     * number number, and numCredits credits
     *
     * @param dept - the department in which this course belongs
     * @param number - the number of this course
     * @param numCredits - the number of credits this course is worth
     */
    CreditCourse(String dept, int number, int numCredits){

    }

    // Getters and Setters

    /**
     * Returns the course's department
     * @return deparment code
     */
    public String getDepartment(){
	return null;
    }

    /**
     * Sets course's department code
     */
    public void setDepartment(String department){

    }

    /**
     * Returns the course's number
     * @return course number
     */
    public int getNumber(){
	return -1;
    }

    /**
     * Sets course's number
     */
    public void setNumber(int number){

    }

    /**
     * Returns the course's credits
     * @return number of credits
     */
    public int getCredits(){
	return -1;
    }

    /**
     * Sets course's number of credits
     */
    public void setCredits(int credits){

    }


    // Utility Methods

    /**
     * Compares this course to other 
     * Courses are ordered by
     * department, then by course number
     *
     * @param other - the course to compare
     * @return a negative integer if this course comes before other, 0 if they are the
     *          same course, or a positive if this course comes after other
     */
    @Override
    public int compareTo(CreditCourse other){
	return 0;
    }

    /**
     * Compares this course to other 
     * 
     *
     * @param other - the course to compare
     * @return true if this and other department's and course 
     *         numbers are equal, false otherwise
     */
    public boolean equals(CreditCourse other){
	return false;
    }

    /**
     * Returns representation of this object in the format
     * (credits)dept number 
     *
     * For example:
     * (3)CS 221
     * 
     * @return (credits)dept number 
     */
    @Override
    public String toString(){
	return null;
    }
    
}

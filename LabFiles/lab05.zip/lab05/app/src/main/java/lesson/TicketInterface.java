package lesson;
/**
 * Represents an event ticket
 * DO NOT MODIFY THIS FILE
 * @author krodgers
 */  

public interface TicketInterface {
    public enum Event{SPORT, CONCERT, PERFORMANCE};

    /**
     * Returns the type of event for which this
     * ticket was issued
     */
    public Event getEvent();
    
    /**
     * Returns the date of the event for
     * which this ticket grants access in the
     * format mm/dd/yyyy
     */ 
    public String getDate();

    /**
     * Returns the ticket holder's name
     */ 
    public String getName();

    /**
     * Returns the specific spot where the ticket
     * holder will sit
     */ 
    public int getLocation();

    /**
     * Returns the price of the ticket
     */
    public double getCost();

}

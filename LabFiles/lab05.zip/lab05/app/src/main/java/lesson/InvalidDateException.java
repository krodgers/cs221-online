package lesson;

/**
 * Exception thrown when date provided is invalid
 * 
 * A date is invalid if any of the following is true:
 * - date is not in the format mm/dd/yyyy
 * - month is outside the range [1, 12]
 * - day is outside the range [1, 31]
 * - year is earlier than the current year
 * 
 * @author krodgers
 */ 

public class InvalidDateException extends RuntimeException{

    // TODO - implement the constructor
}

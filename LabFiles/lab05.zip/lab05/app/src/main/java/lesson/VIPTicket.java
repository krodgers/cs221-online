package lesson;

/**
 * Represents a ticket that allows the user access to a specific box
 * @author TODO
 */

public class VIPTicket extends BasicTicket{
    // TODO - Copy your VIPTicket file into this folder and overwrite
    // this file or copy your code into this file
}

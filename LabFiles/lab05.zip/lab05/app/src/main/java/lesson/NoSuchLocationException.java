package lesson;

/**
 * Exception thrown when location cannot be found
 * DO NOT MODIFY THIS FILE 
 * @author krodgers
 */ 

 public class NoSuchLocationException extends RuntimeException{

    public NoSuchLocationException(String msg){
	super(msg);
    }

}

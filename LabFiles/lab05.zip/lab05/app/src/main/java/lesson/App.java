package lesson;
import java.io.FileNotFoundException;

/**
 * Processes a ticket summary file in the following format:
 *  <Event Type>
    <Event Date>
    <Name of Ticket Purchaser>
    <Zone or Box #>

 * and prints summary data of the file
 * 
 * @author krodgers, TODO
 */ 
public class App {
    
    public static void main(String[] args) {
        // Some file names. Add others to test your code
	// You can find the text files in app/
        final String VALID_DATAFILE = "validMultipleTicketData.txt";
        final String INVALID_ZONE_DATA = "invalidZoneData.txt";
        final String INVALID_DATE_DATA = "invalidDateMonthData.txt";
        final String MISSING_DATA = "invalidMissingEventData.txt";
        
        
        try{
	    // TODO
            // Create TicketProcessing object using one of the file
            // strings above as the filename

	    // TODO
            // Print sales summary (toString on TicketProcessing object)


        } catch(Exception e){
	    // TODO - catch exceptions as specified in Retrospective.md
        } finally{
	    // This block always runs, whether an exception was thrown
	    // or not
            System.out.println("Done processing");
        }

    }
}

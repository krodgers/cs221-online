package lesson;

/**
 * Represents a ticket that allows the user access to a specific zone
 * @author TODO
 */

public class FloorTicket extends BasicTicket{
    // TODO - Copy your FloorTicket file into this folder and overwrite
    // this file or copy your code into this file
    
}

package lesson;

/**
 * Represents a generic ticket
 * DO NOT MODIFY THIS FILE
 * @author krodgers
 */

public abstract class BasicTicket implements TicketInterface{
    private String name;
    private TicketInterface.Event event;
    private String date;

    // Starting price for all tickets
    private final double BASE_PRICE = 16;
        

    public BasicTicket(String name, TicketInterface.Event event, String date){
        this.name = name;
        this.event = event;
        this.date = date;
    }


    @Override
    public abstract int getLocation();
    

    @Override
    public Event getEvent() {
        return event;
    }

    @Override
    public String getDate() {
        return date;
    }

    @Override
    public String getName() {
        return name;
    }
    
    @Override
    public double getCost(){
        return BASE_PRICE;
    }
     
}

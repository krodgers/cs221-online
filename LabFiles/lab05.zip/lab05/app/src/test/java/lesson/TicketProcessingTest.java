package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

import java.io.FileNotFoundException;

/**
 * Tests TicketProcessing class
 *  
 * Verifies the following test cases:
 * - TicketProcessing can successfully read a file containing one ticket
 * - TicketProcessing's toString method returns a valid string
 * [TODO - list scenarios that are tested]
 * 
 * @author krodgers, TODO
 */ 
public class TicketProcessingTest {

    // Base cost of a ticket
    private final double BASE_COST = 16;

    /**
     * Helper method to test total tickets and total revenue is correct
     * Is not a stand alone test method, but is to be called from other
     * tests.  
     * 
     * DO NOT MODIFY THIS METHOD
     *
     * @param actual - TicketProcessing object for which to test getters
     * @param expectedTickets - the expected total number of tickets
     * @param expectedTotalRevenue - the expected total revenue
     */
    private void getterHelperTest(TicketProcessing actual, int expectedTickets,
				  double expectedTotalRevenue){
	assertEquals(actual.totalTicketsSold(), expectedTickets);
	assertEquals(actual.getTotalRevenue(), expectedTotalRevenue);
    }

    // ensure valid file doesn't throw any exceptions
    @Test
    public void validFileOneTicketTest() throws FileNotFoundException{
        TicketProcessing process = new TicketProcessing("validOneTicketData.txt");
	getterHelperTest(process, 1, BASE_COST * 2);
    }

    // verify toString is correct
    @Test
    public void toStringTest() throws FileNotFoundException{
        TicketProcessing process = new TicketProcessing("validMultipleTicketData.txt");
        String expected = "Total number of tickets sold: 3\nTotal Revenue: $192.00\nTotal Sports Revenue: $64.00\nTotal Performance Revenue: $32.00\nTotal Concert Revenue: $96.00";
        assertEquals(process.toString(), expected);
    }

    // Tests default revenue values are correct
    @Test
    public void getRevenueTest() throws FileNotFoundException{
        TicketProcessing process = new TicketProcessing("validMultipleTicketData.txt");
        double expectedCost = BASE_COST * 12;
        assertEquals(process.totalTicketsSold(), 3, "Total tickets incorrect");
        assertEquals(process.getTotalRevenue(), expectedCost, "Total revenue incorrect");
        assertEquals(process.getRevenue(TicketInterface.Event.SPORT), BASE_COST * 4);
        assertEquals(process.getRevenue(TicketInterface.Event.CONCERT), BASE_COST * 6);
        assertEquals(process.getRevenue(TicketInterface.Event.PERFORMANCE), BASE_COST * 2);
    }

    // verify reading a new file doesn't throw exceptions
    // verify data has been cleared
    @Test
    public void newTicketFileTest() throws FileNotFoundException{
	TicketProcessing process = new TicketProcessing("validOneTicketData.txt");
    	process.readTicketData("validMultipleTicketData.txt");
	getterHelperTest(process, 3, BASE_COST * 12);
    }
    
    
    // read from file that does not exist
    // ensure FileNotFoundException is thrown
    @Test(expectedExceptions = FileNotFoundException.class)
    public void fileMissingTest() throws FileNotFoundException{
    	TicketProcessing process = new TicketProcessing("dne.txt");
    }

    // Should throw an IllegalArgumentException - it's missing data
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void emptyTicketFileTest() throws FileNotFoundException{
	// TODO - create a new TicketProcessing object using emptyTicketData.txt
	// Use fileMissingTest() as an example

	fail(); // delete this line when you implement this method
    }

    // read from invalid file
    // ensure invalid date exception thrown correctly
    @Test(expectedExceptions = InvalidDateException.class)
    public void invalidDateDayTest() throws FileNotFoundException{
        TicketProcessing process = new TicketProcessing("invalidDateDayData.txt");
    }

    // read from invalid file
    // ensure invalid date exception thrown correctly
    @Test(expectedExceptions = InvalidDateException.class)
    public void invalidDateMonthTest() throws FileNotFoundException{
        TicketProcessing process = new TicketProcessing("invalidDateMonthData.txt");
    }

    // read from invalid file
    // ensure invalid date exception thrown correctly
    @Test(expectedExceptions = InvalidDateException.class)
    public void invalidDateYearTest() throws FileNotFoundException{
	// TODO - use invalidDateYearData.txt to test TicketProcessing
	// correctly throws InvalidDateException with an out of range
	// year

	fail(); // delete this line when you implement this method
    }


    
    // read from invalid file
    // ensure NoSuchLocationException thrown correctly
    @Test(expectedExceptions = NoSuchLocationException.class)
    public void noSuchZoneTest() throws FileNotFoundException{
	TicketProcessing process = new TicketProcessing("invalidZoneData.txt");
    }

    // read from invalid file
    // ensure NoSuchLocationException thrown correctly
    // ensure NoSuchLocationException message is correct
    @Test
    public void noSuchBoxTest() throws FileNotFoundException{
	try{
            TicketProcessing process = new TicketProcessing("invalidBoxData.txt");
        } catch(NoSuchLocationException e){
            assertEquals(e.getMessage(), "NoSuchLocationException: Box or Zone value is invalid");
        }
    }


    // read from file with missing event
    // ensure IllegalArgumentException is thrown
    // ensure IllegalArgumentException has the correct message
    @Test
    public void fileMissingEventTest() throws FileNotFoundException{
	// TODO - implement this method like noSuchBoxTest() was implemented
	// Use file invalidMissingEventData.txt
	// Catch the exception and make sure its message is correct

	fail(); // remove this line when you implement this method
    }




    /**
       TODO - implement the next three methods 

       For each method, choose one of invalidMissingDateData.txt,
       invalidMissingNameData.txt, or invalidMissingLocationData.txt
       as appropriate.  You should use each file exactly once. 

       Construct a TicketProcessing object to ensure the proper
       exception is thrown.
     */

    
    // read from file with missing date
    // ensure IllegalArgumentException is thrown
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void fileMissingDateTest() throws FileNotFoundException{

	// TODO - implement as instructed in comment above
	fail(); // remove this line when you implement this method
    }
    
    // read from file with missing name
    // ensure IllegalArgumentException is thrown
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void fileMissingNameTest() throws FileNotFoundException{
	// TODO - implement as instructed in comment above
	fail(); // remove this line when you implement this method
    }
    

    // read from file with missing seat/box
    // ensure IllegalArgumentException is thrown
    @Test(expectedExceptions = IllegalArgumentException.class)
    public void fileMissingLocationTest() throws FileNotFoundException{
	// TODO - implement as instructed in comment above
	fail(); // remove this line when you implement this method
    }

}

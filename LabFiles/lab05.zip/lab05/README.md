# Lab 5: Ticket Processing (part 2)

## Learning Objectives

- Apply inheritance and polymorphism
- Write exception safe code
- Understand the difference between checked and unchecked exceptions.
- Apply using the try/catch keywords
- Explore different approaches to handling exceptions in an application

## Overview

This project contains the following source files:

- App.java - Driver class; uses TicketProcessing to read a ticket data
  	     file and print a summary of the file.  It should gracefully handle
	     all exceptions raised [read: shouldn't crash]
- TicketInterface.java - Interface defining methods all tickets should have
- BasicTicket.java - Abstract class implementing methods that will be
		   the same for all tickets
- VIPTicket.java - Child class of BasicTicket. Represents a box seat
  		   ticket.  You should copy your file from the last
  		   lab and overwrite this file.
- FloorTicket.java - Child class of BasicTicket. Represents a ticket
		   for a specific zone. You should copy your file from
		   the last lab and overwrite this file.
- TicketProcessing.java - Class for reading and storing information
  			  from a ticket sales summary file.  You need
  			  to implement several methods in this class
  			  and add exception handling

and the following test files:

- TicketProcessingTest.java - Contains tests for
  			      TicketProcessing. Most of the test
  			      methods are implemented.  You should
  			      read the ones that are implemented and
  			      use them to implement the rest of the
  			      tests.


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run this project on *nix system:
./gradlew run

To run this project on Windows:
start gradlew.bat run


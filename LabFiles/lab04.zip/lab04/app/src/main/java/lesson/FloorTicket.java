package lesson;

public class FloorTicket extends BasicTicket{
    // TODO: Needs two more private instace variables - double cost
    // and int zone


    // TODO: FloorTicket constructor
    // Remember to call super(...) to
    // initialize instance variables from BasicTicket

    // TODO: Override getLocation

    // TODO: Override getCost

    // TODO: Override toString

}

package lesson;

/**
 * Represents a ticket for a box seat
 * @author
 */
public class VIPTicket extends BasicTicket{
    // TODO: VIPTicket needs a private double cost and private int box


    // TODO: Constructor
    // Don't forget to call super( ...) to initialize instance variables
    // stored in BasicTicket



    // TODO: Override getLocation

    // TODO: Override getCost

    // TODO: Override toString
    
}

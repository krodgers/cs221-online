package lesson;
import java.util.ArrayList;


/**
 * Creates ArrayList of Ticket object and tallies the number of each kind of event
 * Feel free to experiment with this file
 * @author krodgers
 */ 
public class App {

    public static void main(String[] args) {
        // Since all classes implememnt TicketInterface,
        // objects of any ticket class can have TicketInterface as 
        // the reference type
        ArrayList<TicketInterface> ticketsSold = new ArrayList<TicketInterface>();
        
        // Add tickets to tickets sold
        ticketsSold.add(new FloorTicket("Homer", TicketInterface.Event.CONCERT, "01/02/2033", 19));
        ticketsSold.add(new FloorTicket("Marge", TicketInterface.Event.CONCERT, "01/02/2033", 20));

        ticketsSold.add(new VIPTicket("Simon", TicketInterface.Event.PERFORMANCE, "08/15/2045", 3));
        ticketsSold.add(new VIPTicket("Lilo", TicketInterface.Event.SPORT, "09/25/2032", 7));
       
        // Compute the number of tickets sold to each event
        int concertCount = 0;
        int perfCount = 0;
        int sportCount = 0;
        for(TicketInterface ticket : ticketsSold){
            System.out.println(ticket);
            TicketInterface.Event eventType = ticket.getEvent();
            switch(eventType){
                case CONCERT:
                    concertCount++;
                    break;
                case SPORT:
                    sportCount++;
                    break;
                case PERFORMANCE:
                    perfCount++;
                    break;
                default:
                    System.out.println("Event type unknown");
            }
        }

        // Print results
        System.out.printf("%10s%10s%20s\n", "Concerts", "Sports", "Performances");
        System.out.printf("%10d%10d%20d\n", concertCount, perfCount, sportCount);

    }
}

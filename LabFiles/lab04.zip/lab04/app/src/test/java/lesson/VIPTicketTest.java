package lesson;

import org.testng.annotations.Test;
import static org.testng.Assert.*;

/**
 * Tests VIPTicket class
 * @author 
 */

public class VIPTicketTest {
    // TODO: Test Getters
    // TODO: Test cheaper box price
    // TODO: Test expensive box price
    // TODO: Test toString
        

}

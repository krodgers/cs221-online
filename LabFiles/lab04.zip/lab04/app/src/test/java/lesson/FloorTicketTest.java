package lesson;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.*;

/**
 *  Tests functionality of FloorTicket
 * 
 * @author krodgers
 */ 
public class FloorTicketTest {

        
    // Test getters
    @Test
    public void testFloorTicketGetters(){
        FloorTicket ticket = new FloorTicket("Luna", TicketInterface.Event.SPORT, "01/02/1234", 35);

        assertEquals(ticket.getCost(), 32);
        assertEquals(ticket.getDate(), "01/02/1234");
        assertEquals(ticket.getEvent(), TicketInterface.Event.SPORT);
        assertEquals(ticket.getLocation(), 35);
        assertEquals(ticket.getName(), "Luna");
    }

    // Test toString
    @Test
    public void testFloorTicketToString(){
        FloorTicket ticket = new FloorTicket("Lilo Cat", TicketInterface.Event.CONCERT, "03/16/1470", 100);
        String expected = "Lilo Cat\n03/16/1470:Zone 100";
        assertEquals(ticket.toString(), expected);
    }

}

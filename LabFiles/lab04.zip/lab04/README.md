# Lab 4: Ticket Processing (part 1)

## Learning Objectives

- Describe the differences between an Interface and Abstract class
- Apply inheritance and polymorphism
- Write a properly encapsulated class

## Overview

This project contains the following source files:

- App.java - Driver class; creates ArrayList of Tickets and prints the
	   total number of tickets for each type of event
- TicketInterface.java - Interface defining methods all tickets should have
- BasicTicket.java - Abstract class implementing methods that will be
		   the same for all tickets
- VIPTicket.java - Child class of BasicTicket. Represents a box seat ticket.
  		   You should implement this class
- FloorTicket.java - Child class of BasicTicket. Represents a ticket for
		   a specific zone. You should implement this class

and the following test files:

- FloorTicketTest.java - contains tests for FloorTicket objects;
  		       	 discussed in lab overview video and needs to
  		       	 be fully implemented
- VIPTicketTest.java - contains tests for VIPTicket objects. You need
  		       to implement this class


## Building and Testing
To build this project on Linux, MacOS, or from a VSCode terminal, run
./gradlew build

From a windows terminal, run
start gradlew.bat build


This will compile all of the sources files.  If compilation was
successful, it will also display the results of the tests that were
run.

## Running
To run this project on *nix system:
./gradlew run

To run this project on Windows:
start gradlew.bat run

